public interface Performance {
	float credit();
	float monthlyFee();
}